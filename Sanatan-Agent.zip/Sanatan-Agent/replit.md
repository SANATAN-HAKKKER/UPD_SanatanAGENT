# SanatanAGENT

## Overview

SanatanAGENT is an AI chat application built as a ChatGPT-like interface. It provides conversational AI capabilities with real-time streaming responses, conversation management, and file upload functionality for training data. The application uses a modern React frontend with an Express backend, powered by OpenAI's API through Replit AI Integrations.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state, local React state for UI
- **Styling**: Tailwind CSS with shadcn/ui component library (New York style)
- **Animations**: Framer Motion for smooth UI transitions
- **Build Tool**: Vite with HMR support

The frontend follows a page-based structure with reusable components. Key pages include Home (landing with suggestions) and Chat (conversation view). The UI is dark-themed, inspired by ChatGPT's design.

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **API Pattern**: RESTful endpoints with SSE (Server-Sent Events) for streaming chat responses
- **Database**: PostgreSQL with Drizzle ORM
- **AI Integration**: OpenAI API via Replit AI Integrations (supports chat and image generation)

Routes are organized in `server/routes.ts` with AI-specific routes modularized under `server/replit_integrations/`. The storage layer uses a DatabaseStorage class pattern for data access.

### Data Layer
- **ORM**: Drizzle ORM with Zod schema validation
- **Schema Location**: `shared/schema.ts` and `shared/models/chat.ts`
- **Tables**:
  - `conversations`: Stores chat sessions with title and timestamp
  - `messages`: Stores individual messages linked to conversations
  - `files`: Stores uploaded text content for training data

### API Structure
- `GET/POST /api/conversations` - List and create conversations
- `GET/DELETE /api/conversations/:id` - Get or delete specific conversation
- `POST /api/conversations/:id/messages` - Send message with SSE streaming response
- `GET/POST/DELETE /api/files` - File management for training data
- `POST /api/generate-image` - Image generation endpoint

### Build System
- Development: `tsx` for TypeScript execution with Vite dev server
- Production: esbuild bundles server, Vite builds client to `dist/`
- Database migrations: `drizzle-kit push` for schema synchronization

## External Dependencies

### AI Services
- **OpenAI API**: Connected via Replit AI Integrations using environment variables `AI_INTEGRATIONS_OPENAI_API_KEY` and `AI_INTEGRATIONS_OPENAI_BASE_URL`
- **Models Used**: GPT for chat completions, gpt-image-1 for image generation

### Database
- **PostgreSQL**: Required via `DATABASE_URL` environment variable
- **Session Storage**: connect-pg-simple for Express sessions (available but not currently active)

### Key NPM Packages
- `drizzle-orm` / `drizzle-zod`: Database ORM and schema validation
- `openai`: Official OpenAI SDK
- `@tanstack/react-query`: Async state management
- `framer-motion`: Animation library
- Radix UI primitives: Accessible component foundations
- `p-limit` / `p-retry`: Batch processing utilities for rate limiting