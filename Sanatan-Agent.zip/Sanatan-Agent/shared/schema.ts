import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export * from "./models/chat";

export const visitors = pgTable("visitors", {
  id: serial("id").primaryKey(),
  ip: text("ip").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertVisitorSchema = createInsertSchema(visitors).omit({ id: true, createdAt: true });
export type Visitor = typeof visitors.$inferSelect;
export type InsertVisitor = z.infer<typeof insertVisitorSchema>;

export const files = pgTable("files", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  content: text("content").notNull(), // Simple text storage for "trained data"
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const schoologyAuth = pgTable("schoology_auth", {
  id: serial("id").primaryKey(),
  accessToken: text("access_token"),
  accessTokenSecret: text("access_token_secret"),
  requestToken: text("request_token"),
  requestTokenSecret: text("request_token_secret"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  verificationCode: text("verification_code"),
  isVerified: integer("is_verified").default(0).notNull(), // 0: false, 1: true
  isDev: integer("is_dev").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true, isVerified: true, isDev: true });
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export const insertSchoologyAuthSchema = createInsertSchema(schoologyAuth).omit({ id: true, updatedAt: true });
export type SchoologyAuth = typeof schoologyAuth.$inferSelect;
export type InsertSchoologyAuth = z.infer<typeof insertSchoologyAuthSchema>;

export const insertFileSchema = createInsertSchema(files).omit({ id: true, createdAt: true });
export type File = typeof files.$inferSelect;
export type InsertFile = z.infer<typeof insertFileSchema>;
