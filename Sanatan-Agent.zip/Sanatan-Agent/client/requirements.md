## Packages
framer-motion | For smooth UI transitions and message entry animations
clsx | For conditional class merging
tailwind-merge | For merging tailwind classes intelligently
date-fns | For formatting dates in the sidebar

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  display: ["Plus Jakarta Sans", "sans-serif"],
}
