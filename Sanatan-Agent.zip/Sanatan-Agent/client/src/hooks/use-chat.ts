import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { conversations, messages } from "@shared/schema";
import { useState, useRef, useEffect } from "react";

// ============================================
// Hook: Fetch Conversations List
// ============================================
export function useConversations() {
  return useQuery({
    queryKey: [api.chat.list.path],
    queryFn: async () => {
      const res = await fetch(api.chat.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch conversations");
      return api.chat.list.responses[200].parse(await res.json());
    },
  });
}

// ============================================
// Hook: Fetch Single Conversation with Messages
// ============================================
export function useConversation(id: number | null) {
  return useQuery({
    queryKey: [api.chat.get.path, id],
    enabled: !!id,
    queryFn: async () => {
      if (!id) return null;
      const url = buildUrl(api.chat.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch conversation");
      return api.chat.get.responses[200].parse(await res.json());
    },
  });
}

// ============================================
// Hook: Create New Conversation
// ============================================
export function useCreateConversation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (title?: string) => {
      const res = await fetch(api.chat.create.path, {
        method: api.chat.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create conversation");
      return api.chat.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.chat.list.path] });
    },
  });
}

// ============================================
// Hook: Delete Conversation
// ============================================
export function useDeleteConversation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.chat.delete.path, { id });
      const res = await fetch(url, { 
        method: api.chat.delete.method, 
        credentials: "include" 
      });
      if (!res.ok) throw new Error("Failed to delete conversation");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.chat.list.path] });
    },
  });
}

// ============================================
// Hook: Stream Chat Message (SSE)
// ============================================
export function useChatStream(conversationId: number | null) {
  const queryClient = useQueryClient();
  const [streamingContent, setStreamingContent] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const sendMessage = async (content: string) => {
    if (!conversationId) return;

    setIsStreaming(true);
    setStreamingContent("");
    setError(null);

    // Optimistically update UI could happen here, but simplest is to wait for stream start
    
    try {
      const res = await fetch(`/api/conversations/${conversationId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content }),
        credentials: "include", // Important for cookies if auth is used
      });

      if (!res.ok) throw new Error("Failed to send message");
      if (!res.body) throw new Error("ReadableStream not supported");

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        buffer += chunk;
        
        const lines = buffer.split("\n\n");
        buffer = lines.pop() || ""; // Keep the last incomplete line in buffer

        for (const line of lines) {
          if (line.startsWith("data: ")) {
            const jsonStr = line.slice(6);
            try {
              const data = JSON.parse(jsonStr);
              if (data.done) {
                // Stream finished
                setIsStreaming(false);
                queryClient.invalidateQueries({ queryKey: [api.chat.get.path, conversationId] });
                setStreamingContent(""); // Clear transient state as query will now have full msg
              } else if (data.content) {
                setStreamingContent(prev => prev + data.content);
              } else if (data.error) {
                setError(data.error);
                setIsStreaming(false);
              }
            } catch (e) {
              console.error("Failed to parse SSE line", e);
            }
          }
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unknown error");
      setIsStreaming(false);
    }
  };

  return { sendMessage, streamingContent, isStreaming, error };
}
