import { useState } from "react";
import { Sidebar } from "@/components/Sidebar";
import { ChatInput } from "@/components/ChatInput";
import { useCreateConversation } from "@/hooks/use-chat";
import { useLocation } from "wouter";
import { Menu, Zap, Terminal, Sparkles, BookOpen, Download } from "lucide-react";
import { motion } from "framer-motion";
import { usePWAInstall } from "@/hooks/use-pwa-install";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";

export default function Home() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [, setLocation] = useLocation();
  const createConversation = useCreateConversation();
  const { canInstall, handleInstall } = usePWAInstall();

  const { data: visitorData } = useQuery<{ count: number }>({
    queryKey: ['/api/visitors/count'],
  });

  const handleStartChat = (initialMessage: string) => {
    createConversation.mutate(initialMessage.slice(0, 30), {
      onSuccess: (newChat) => {
        setLocation(`/chat/${newChat.id}?initial=${encodeURIComponent(initialMessage)}`);
      },
    });
  };

  const suggestions = [
    { icon: <Sparkles className="w-5 h-5 text-yellow-400" />, text: "Creative ideas for a 10 year old's birthday?" },
    { icon: <Terminal className="w-5 h-5 text-red-400" />, text: "How do I make an HTTP request in Javascript?" },
    { icon: <BookOpen className="w-5 h-5 text-blue-400" />, text: "Explain quantum computing in simple terms" },
    { icon: <Zap className="w-5 h-5 text-purple-400" />, text: "Write a poem about artificial intelligence" },
  ];

  return (
    <div className="flex h-screen bg-[#212121] text-white font-sans overflow-hidden">
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />

      <main className="flex-1 flex flex-col relative h-full w-full bg-[#212121]">
        {/* Visitor Count */}
        <div className="absolute top-4 right-4 z-50 text-xs text-white/40 font-medium">
          # of users: {visitorData?.count || 0}
        </div>

        {/* Mobile Header */}
        <div className="md:hidden sticky top-0 z-10 flex items-center p-2 text-gray-300 bg-[#343541] border-b border-white/5">
          <button 
            onClick={() => setIsSidebarOpen(true)}
            className="p-2 -ml-2 rounded-md hover:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white"
          >
            <Menu className="w-6 h-6" />
          </button>
          <div className="flex-1 text-center font-medium">New Chat</div>
          <div className="w-10" /> {/* Spacer */}
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-y-auto">
          <div className="flex flex-col items-center justify-center h-full px-4 text-center">
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="mb-6 p-4 rounded-full bg-white/5 border border-white/10 shadow-2xl shadow-black/20 relative z-50"
            >
              <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center">
                <span className="text-black font-bold text-xl">SA</span>
              </div>
              <Button
                variant="outline"
                size="icon"
                className="absolute -top-1 -right-1 h-6 w-6 rounded-full bg-white text-black border-none hover:bg-gray-200 z-50 flex items-center justify-center"
                onClick={handleInstall}
                title="Download App"
              >
                <Download className="w-3 h-3" />
              </Button>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="mb-12 relative z-50"
            >
              <div className="flex flex-col items-center gap-2">
                <h1 className="text-4xl font-semibold font-display tracking-tight">
                  SanatanAGENT
                </h1>
                <div className="flex flex-col sm:flex-row gap-2 mt-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-xs text-blue-400 hover:text-blue-300 hover:bg-blue-400/10 gap-1.5 z-50 flex items-center"
                    onClick={() => setLocation('/schoology')}
                  >
                    Schoology Scan
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="text-xs text-blue-400 hover:text-blue-300 hover:bg-blue-400/10 gap-1.5 z-50 flex items-center"
                    onClick={handleInstall}
                  >
                    <Download className="w-3 h-3" />
                    Download App
                  </Button>
                </div>
              </div>
              <p className="text-gray-400 text-lg mt-2">
                made by Sanatan Sinha
              </p>
            </motion.div>
          </div>
        </div>

        {/* Input Area */}
        <div className="w-full bg-gradient-to-t from-[#343541] via-[#343541] to-transparent pt-10">
          <ChatInput onSend={handleStartChat} isLoading={createConversation.isPending} />
        </div>
      </main>
    </div>
  );
}
