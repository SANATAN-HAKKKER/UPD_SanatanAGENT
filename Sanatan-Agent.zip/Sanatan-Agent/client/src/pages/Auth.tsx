import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { GraduationCap, Loader2, Mail } from "lucide-react";

export default function AuthPage() {
  const { user, login, register, verify, isLoading } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [code, setCode] = useState("");

  if (isLoading) return <div className="flex items-center justify-center min-h-screen bg-[#212121]"><Loader2 className="animate-spin text-white" /></div>;
  if (user && user.isVerified) return <Redirect to="/" />;
  
  if (user && !user.isVerified) {
    return (
      <div className="min-h-screen bg-[#212121] flex items-center justify-center p-4">
        <Card className="w-full max-w-md bg-[#2f2f2f] border-none text-white">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Mail className="w-6 h-6 text-primary" />
              Verify your Email
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-gray-400">
              We've sent a 6-digit verification code to {user.email}. (Check server logs for simulation)
            </p>
            <Input 
              placeholder="Enter 6-digit code" 
              className="bg-[#212121] border-white/10"
              value={code}
              onChange={(e) => setCode(e.target.value)}
            />
            <Button className="w-full" onClick={() => verify(code)}>Verify</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#212121] flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-[#2f2f2f] border-none text-white">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center">
              <span className="text-black font-bold text-xl">SA</span>
            </div>
          </div>
          <CardTitle className="text-2xl font-bold">Welcome to SanatanAGENT</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-[#212121] mb-6">
              <TabsTrigger value="login">Login</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>
            <TabsContent value="login" className="space-y-4">
              <Input placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} className="bg-[#212121] border-white/10" />
              <Input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} className="bg-[#212121] border-white/10" />
              <Button className="w-full" onClick={() => login({ email, password })}>Login</Button>
            </TabsContent>
            <TabsContent value="register" className="space-y-4">
              <Input placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} className="bg-[#212121] border-white/10" />
              <Input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} className="bg-[#212121] border-white/10" />
              <Button className="w-full" onClick={() => register({ email, password })}>Sign Up</Button>
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="text-center text-xs text-gray-500">
          By continuing, you agree to our Terms of Service.
        </CardFooter>
      </Card>
    </div>
  );
}
