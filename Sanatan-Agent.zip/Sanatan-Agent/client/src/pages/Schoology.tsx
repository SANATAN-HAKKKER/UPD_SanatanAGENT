import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { GraduationCap, Book, ClipboardList, Send, Sparkles, Image as ImageIcon, Link as LinkIcon, Upload, Loader2, CheckCircle2, BookOpen } from "lucide-react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useCreateConversation } from "@/hooks/use-chat";

export default function SchoologyPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const createConversation = useCreateConversation();
  const [assignmentText, setAssignmentText] = useState("");
  const [assignmentLink, setAssignmentLink] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedImage(e.target.files[0]);
      toast({
        title: "Image attached",
        description: `${e.target.files[0].name} is ready for scanning.`,
      });
    }
  };

  const handleScan = async () => {
    if (!assignmentText.trim() && !selectedImage && !assignmentLink.trim()) {
      toast({
        title: "Nothing to scan",
        description: "Please provide an assignment text, link, or screenshot.",
        variant: "destructive",
      });
      return;
    }

    setIsAnalyzing(true);
    let prompt = "SCHOOLOGY ASSIGNMENT SCAN:\n\n";
    if (assignmentText.trim()) prompt += `TEXT:\n${assignmentText}\n\n`;
    if (assignmentLink.trim()) prompt += `LINK:\n${assignmentLink}\n\n`;
    if (selectedImage) prompt += `SCREENSHOT ATTACHED (Processed as OCR context)\n\n`;
    
    prompt += "Analyze this assignment and guide me through how to solve it. DO NOT give me the direct answers. Instead, provide a step-by-step explanation of the concepts and steps I need to take to find the answer myself.";

    createConversation.mutate("Assignment Scan: " + (assignmentText.slice(0, 20) || "Screenshot/Link"), {
      onSuccess: (newChat) => {
        setLocation(`/chat/${newChat.id}?initial=${encodeURIComponent(prompt)}`);
      },
      onError: () => {
        setIsAnalyzing(false);
        toast({
          title: "Scan failed",
          description: "Something went wrong while sending to agent.",
          variant: "destructive",
        });
      }
    });
  };

  return (
    <div className="min-h-screen bg-[#212121] text-white p-8 overflow-y-auto">
      <div className="max-w-4xl mx-auto">
        <header className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <GraduationCap className="w-10 h-10 text-primary" />
            <h1 className="text-3xl font-bold font-display">Schoology Smart Scan</h1>
          </div>
          <Button variant="ghost" onClick={() => setLocation('/')} className="text-gray-400 hover:text-white">
            Back to Home
          </Button>
        </header>

        <div className="mb-8 p-4 bg-yellow-400/10 border border-yellow-400/20 rounded-lg">
          <p className="text-sm text-yellow-500 font-medium">
            Note: SanatanAGENT is a learning assistant. It will never provide direct answers to assignments. Instead, it will guide you through the concepts and steps so you can solve them yourself.
          </p>
        </div>

        <div className="space-y-6">
          <Card className="bg-[#2f2f2f] border border-white/5 text-white">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-yellow-400" />
                No Login Required
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-400 mb-6">
                Since we want to keep it simple, you don't need a Schoology API key. Just copy the text from your Schoology assignment and paste it below. SanatanAGENT will scan it and guide you through the solution steps.
              </p>
              
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="relative">
                    <div className="flex items-center gap-2 mb-2 text-sm text-gray-400">
                      <ImageIcon className="w-4 h-4" />
                      Screenshot
                    </div>
                    <input 
                      type="file" 
                      accept="image/*" 
                      className="hidden" 
                      ref={fileInputRef}
                      onChange={handleImageChange}
                    />
                    <Button 
                      variant="outline" 
                      className="w-full h-24 border-dashed border-white/10 bg-[#212121] hover:bg-white/5 flex flex-col gap-2"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      {selectedImage ? (
                        <>
                          <CheckCircle2 className="w-6 h-6 text-green-500" />
                          <span className="text-xs truncate max-w-full px-2">{selectedImage.name}</span>
                        </>
                      ) : (
                        <>
                          <Upload className="w-6 h-6 text-gray-500" />
                          <span className="text-xs text-gray-500">Upload Screenshot</span>
                        </>
                      )}
                    </Button>
                  </div>

                  <div className="relative">
                    <div className="flex items-center gap-2 mb-2 text-sm text-gray-400">
                      <LinkIcon className="w-4 h-4" />
                      Assignment Link
                    </div>
                    <Input 
                      placeholder="https://schoology.com/..."
                      className="h-24 bg-[#212121] border-white/10 text-white placeholder:text-gray-600 focus:ring-primary"
                      value={assignmentLink}
                      onChange={(e) => setAssignmentLink(e.target.value)}
                    />
                  </div>
                </div>

                <div className="relative">
                  <div className="flex items-center gap-2 mb-2 text-sm text-gray-400">
                    <BookOpen className="w-4 h-4" />
                    Assignment Text
                  </div>
                  <Textarea 
                    placeholder="Paste assignment text, questions, or instructions here..."
                    className="min-h-[120px] bg-[#212121] border-white/10 text-white placeholder:text-gray-600 focus:ring-primary"
                    value={assignmentText}
                    onChange={(e) => setAssignmentText(e.target.value)}
                  />
                </div>

                <Button 
                  onClick={handleScan} 
                  disabled={isAnalyzing}
                  size="lg" 
                  className="w-full bg-primary hover:bg-primary/90 text-white gap-2 h-12 text-lg font-medium shadow-lg shadow-primary/20"
                >
                  {isAnalyzing ? (
                    <>Scanning assignment...</>
                  ) : (
                    <>
                      <Send className="w-5 h-5" />
                      Scan & Get Guidance
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="bg-[#2f2f2f]/50 border-none text-white p-6">
              <div className="flex items-center gap-3 mb-3">
                <Book className="w-6 h-6 text-blue-400" />
                <h3 className="font-semibold text-lg">How to use</h3>
              </div>
              <ol className="text-sm text-gray-400 space-y-2 list-decimal list-inside">
                <li>Go to your assignment in Schoology</li>
                <li>Highlight and copy all the text/questions</li>
                <li>Paste it into the box above</li>
                <li>Click "Scan & Get Guidance" to start learning</li>
              </ol>
            </Card>

            <Card className="bg-[#2f2f2f]/50 border-none text-white p-6">
              <div className="flex items-center gap-3 mb-3">
                <ClipboardList className="w-6 h-6 text-green-400" />
                <h3 className="font-semibold text-lg">Why no login?</h3>
              </div>
              <p className="text-sm text-gray-400">
                Official Schoology logins require special developer keys from your school. This "Smart Scan" method works for EVERY student at any school without any setup.
              </p>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
