import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, ShieldCheck, Users, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { User } from "@shared/schema";

export default function DevDashboard() {
  const { user } = useAuth();
  
  const { data: devUsers, isLoading: loadingUsers } = useQuery<User[]>({
    queryKey: ["/api/dev/users"],
    enabled: !!user?.isDev,
  });

  const { data: conversations } = useQuery<any[]>({
    queryKey: ["/api/dev/conversations"],
    enabled: !!user?.isDev,
  });

  if (!user?.isDev) return <Redirect to="/" />;
  if (loadingUsers) return <div className="flex items-center justify-center min-h-screen bg-[#212121]"><Loader2 className="animate-spin text-white" /></div>;

  return (
    <div className="min-h-screen bg-[#212121] text-white p-8 overflow-y-auto">
      <div className="max-w-6xl mx-auto">
        <header className="flex items-center gap-4 mb-8">
          <ShieldCheck className="w-10 h-10 text-primary" />
          <h1 className="text-3xl font-bold">Developer Dashboard</h1>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-[#2f2f2f] border-none text-white">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Total Users</CardTitle>
              <Users className="w-4 h-4 text-gray-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{devUsers?.length || 0}</div>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-[#2f2f2f] border-none text-white mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageSquare className="w-5 h-5" /> Recent User Chats
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {conversations?.map((chat) => (
                <div key={chat.id} className="p-3 bg-[#212121] rounded-lg flex justify-between items-center">
                  <div>
                    <div className="font-medium">{chat.title}</div>
                    <div className="text-xs text-gray-500">{new Date(chat.createdAt).toLocaleString()}</div>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => window.location.href = `/chat/${chat.id}`}>View</Button>
                </div>
              ))}
              {conversations?.length === 0 && <p className="text-gray-500 italic">No chats found.</p>}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-[#2f2f2f] border-none text-white">
          <CardHeader>
            <CardTitle>User Management</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-white/10">
                    <th className="pb-4">Email</th>
                    <th className="pb-4">Role</th>
                    <th className="pb-4">Verified</th>
                    <th className="pb-4">Created At</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {devUsers?.map((u) => (
                    <tr key={u.id} className="hover:bg-white/5 transition-colors">
                      <td className="py-4">{u.email}</td>
                      <td className="py-4">{u.isDev ? "Developer" : "User"}</td>
                      <td className="py-4 text-gray-400">{u.isVerified ? "Yes" : "No"}</td>
                      <td className="py-4 text-gray-400">{u.createdAt ? new Date(u.createdAt).toLocaleDateString() : 'N/A'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
