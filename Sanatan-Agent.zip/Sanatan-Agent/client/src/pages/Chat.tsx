import { useEffect, useRef, useState } from "react";
import { Sidebar } from "@/components/Sidebar";
import { ChatInput } from "@/components/ChatInput";
import { Message } from "@/components/Message";
import { useConversation, useChatStream } from "@/hooks/use-chat";
import { useRoute, useLocation } from "wouter";
import { Menu, Loader2, Download, GraduationCap } from "lucide-react";
import { usePWAInstall } from "@/hooks/use-pwa-install";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";

export default function Chat() {
  const [match, params] = useRoute("/chat/:id");
  const id = params?.id ? parseInt(params.id) : null;
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const { canInstall, handleInstall } = usePWAInstall();

  const { data: visitorData } = useQuery<{ count: number }>({
    queryKey: ['/api/visitors/count'],
  });
  
  // URL Search params for initial message from Home page
  const [location, setLocation] = useLocation();
  const searchParams = new URLSearchParams(window.location.search);
  const initialMessage = searchParams.get("initial");

  const { data: conversation, isLoading: isLoadingConv } = useConversation(id);
  const { sendMessage, streamingContent, isStreaming, error } = useChatStream(id);
  const [hasSentInitial, setHasSentInitial] = useState(false);

  // Scroll to bottom effect
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [conversation?.messages, streamingContent, isStreaming]);

  // Handle initial message from home page redirection
  useEffect(() => {
    if (initialMessage && !hasSentInitial && conversation) {
      sendMessage(initialMessage);
      setHasSentInitial(true);
      // Clean up URL
      window.history.replaceState({}, '', `/chat/${id}`);
    }
  }, [initialMessage, conversation, hasSentInitial, id]);

  if (isLoadingConv) {
    return (
      <div className="flex h-screen bg-[#212121] items-center justify-center text-white">
        <Loader2 className="w-8 h-8 animate-spin opacity-50" />
      </div>
    );
  }

  if (!conversation) {
    return (
      <div className="flex h-screen bg-[#212121] items-center justify-center text-white">
        <div className="text-center">
          <h2 className="text-xl font-bold mb-2">Conversation not found</h2>
          <p className="text-white/50">It may have been deleted.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-[#212121] text-white font-sans overflow-hidden">
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />

      <main className="flex-1 flex flex-col relative h-full w-full bg-[#212121]">
        {/* Visitor Count */}
        <div className="absolute top-4 right-4 z-50 text-xs text-white/40 font-medium hidden md:block">
          # of users: {visitorData?.count || 0}
        </div>

        {/* Mobile Header */}
        <div className="md:hidden sticky top-0 z-10 flex items-center p-2 text-gray-300 bg-[#212121] border-b border-white/5 shadow-md">
          <button 
            onClick={() => setIsSidebarOpen(true)}
            className="p-2 -ml-2 rounded-md hover:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white"
          >
            <Menu className="w-6 h-6" />
          </button>
          <div className="flex-1 text-center font-medium truncate px-4">
            {conversation.title || "New Chat"}
          </div>
          <div className="w-10" />
        </div>

        {/* Model Selector / Top Bar */}
        <div className="hidden md:flex items-center justify-center p-3 border-b border-white/5 bg-[#212121]/50 backdrop-blur-sm sticky top-0 z-50">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-black/20 text-sm font-medium border border-white/5 z-50">
            <div className="flex items-center gap-2 hover:bg-black/10 px-2 py-0.5 rounded cursor-pointer transition-colors">
              <span className="text-green-400">●</span>
              <span>SanatanAGENT</span>
              <span className="text-white/30 text-xs ml-1">v1.0</span>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-7 text-xs text-blue-400 hover:text-blue-300 hover:bg-blue-400/10 gap-1.5 ml-2 border-l border-white/10 pl-4 rounded-none z-50 flex items-center"
              onClick={() => setLocation('/schoology')}
            >
              <GraduationCap className="w-3.5 h-3.5" />
              Schoology
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-7 text-xs text-blue-400 hover:text-blue-300 hover:bg-blue-400/10 gap-1.5 ml-2 border-l border-white/10 pl-4 rounded-none z-50 flex items-center"
              onClick={handleInstall}
            >
              <Download className="w-3.5 h-3.5" />
              Install
            </Button>
          </div>
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-white/10 hover:scrollbar-thumb-white/20">
          <div className="flex flex-col pb-24"> {/* pb-24 for input space */}
            {conversation.messages.map((msg) => (
              <Message 
                key={msg.id} 
                role={msg.role as "user" | "assistant"} 
                content={msg.content} 
              />
            ))}
            
            {/* Streaming Message */}
            {isStreaming && (
              <Message 
                role="assistant" 
                content={streamingContent} 
                isStreaming={true}
              />
            )}
            
            {error && (
              <div className="w-full max-w-3xl mx-auto p-4 mt-4">
                <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm flex items-center justify-center">
                  Error: {error}
                </div>
              </div>
            )}
            
            <div ref={bottomRef} className="h-4" />
          </div>
        </div>

        {/* Input Area */}
        <div className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-[#212121] via-[#212121] to-transparent pt-10 pb-4">
          <ChatInput onSend={sendMessage} isLoading={isStreaming} />
        </div>
      </main>
    </div>
  );
}
