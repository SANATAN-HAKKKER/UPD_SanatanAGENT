import { cn } from "@/lib/utils";
import { Bot, User } from "lucide-react";
import { motion } from "framer-motion";

interface MessageProps {
  role: "user" | "assistant";
  content: string;
  isStreaming?: boolean;
}

export function Message({ role, content, isStreaming }: MessageProps) {
  const isUser = role === "user";

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={cn(
        "group w-full text-gray-100",
        isUser ? "bg-transparent" : "bg-white/5"
      )}
    >
      <div className="text-base gap-4 md:gap-6 md:max-w-2xl lg:max-w-[38rem] xl:max-w-3xl p-4 md:py-4 flex lg:px-0 m-auto">
        <div className="relative flex flex-col items-end">
          <div className={cn(
            "w-8 h-8 rounded-full flex items-center justify-center shrink-0 border border-white/20",
            isUser ? "bg-white/20" : "bg-[#10a37f]"
          )}>
            {isUser ? (
              <User className="w-5 h-5 text-white" />
            ) : (
              <Bot className="w-5 h-5 text-white" />
            )}
          </div>
        </div>

        <div className="relative flex-1 overflow-hidden">
          <div className="font-bold text-white mb-1 text-sm">
            {isUser ? "You" : "SanatanAGENT"}
          </div>
          <div className="prose prose-invert prose-p:leading-relaxed prose-pre:bg-black/50 max-w-none text-[15px] text-white">
            {content.split('\n').map((line, i) => (
              <p key={i} className="mb-4 last:mb-0">{line || '\u00A0'}</p>
            ))}
            {isStreaming && (
              <span className="inline-block w-2 h-4 ml-1 bg-white/70 animate-pulse align-middle" />
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
