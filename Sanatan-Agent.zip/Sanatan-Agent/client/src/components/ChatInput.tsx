import { useState, useRef } from "react";
import { Paperclip, ArrowUp, X, FileText, Loader2 } from "lucide-react";
import { Button } from "./ui/button";
import { useUploadFile } from "@/hooks/use-files";
import { cn } from "@/lib/utils";

interface ChatInputProps {
  onSend: (message: string) => void;
  isLoading: boolean;
}

export function ChatInput({ onSend, isLoading }: ChatInputProps) {
  const [input, setInput] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const uploadFile = useUploadFile();
  const [uploadingFile, setUploadingFile] = useState<string | null>(null);

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isLoading) return;
    onSend(input);
    setInput("");
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Simple validation
    if (file.size > 1024 * 1024) { // 1MB limit for text
      alert("File too large. Please upload text files under 1MB.");
      return;
    }

    setUploadingFile(file.name);

    // Read file content
    const reader = new FileReader();
    reader.onload = async (event) => {
      const content = event.target?.result as string;
      try {
        await uploadFile.mutateAsync({ name: file.name, content });
        setInput((prev) => prev + ` [Uploaded: ${file.name}] `);
      } catch (err) {
        alert("Failed to upload file");
      } finally {
        setUploadingFile(null);
        if (fileInputRef.current) fileInputRef.current.value = "";
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="relative w-full max-w-3xl mx-auto px-4 pb-4 md:pb-6">
      <form onSubmit={handleSubmit} className="relative flex items-end w-full p-3 bg-[#2f2f2f] rounded-2xl shadow-xl shadow-black/5 border border-white/10 ring-offset-2 focus-within:ring-2 focus-within:ring-white/20 transition-all">
        
        {/* Attachment Button */}
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          disabled={uploadingFile !== null}
          className="p-2 text-white/50 hover:text-white transition-colors rounded-lg hover:bg-white/5 mr-2"
          title="Attach text file"
        >
          {uploadingFile ? (
            <Loader2 className="w-5 h-5 animate-spin text-white/50" />
          ) : (
            <Paperclip className="w-5 h-5" />
          )}
        </button>
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleFileSelect} 
          className="hidden" 
          accept=".txt,.md,.json,.csv,.js,.ts,.py"
        />

        {/* Text Area */}
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Message SanatanAGENT..."
          className="flex-1 max-h-[200px] min-h-[24px] bg-transparent border-0 resize-none focus:ring-0 text-white placeholder:text-white/30 py-2 leading-relaxed scrollbar-hide"
          rows={1}
          style={{ height: "auto", minHeight: "24px" }}
          // Simple auto-resize logic could be added here
        />

        {/* Send Button */}
        <button
          type="submit"
          disabled={!input.trim() || isLoading}
          className={cn(
            "p-2 rounded-lg transition-all duration-200 ml-2",
            input.trim() && !isLoading
              ? "bg-white text-black hover:bg-white/90 shadow-lg shadow-white/10"
              : "bg-transparent text-white/20 cursor-not-allowed"
          )}
        >
          {isLoading ? (
            <div className="w-5 h-5 bg-white/20 rounded-sm animate-pulse" />
          ) : (
            <ArrowUp className="w-5 h-5" />
          )}
        </button>
      </form>
      
      <div className="text-center mt-2 text-xs text-white/30 font-medium">
        SanatanAGENT can make mistakes. Consider checking important information.
      </div>
    </div>
  );
}
