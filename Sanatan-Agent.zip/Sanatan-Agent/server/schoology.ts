import { Express } from "express";
import { storage } from "./storage";
import SchoologyAPI from "schoology";

const KEY = process.env.SCHOOLOGY_CONSUMER_KEY;
const SECRET = process.env.SCHOOLOGY_CONSUMER_SECRET;
const CALLBACK_URL = process.env.REPLIT_DEV_DOMAIN 
  ? `https://${process.env.REPLIT_DEV_DOMAIN}/api/schoology/callback`
  : "http://localhost:5000/api/schoology/callback";

export function registerSchoologyRoutes(app: Express) {
  app.get("/api/schoology/auth", (req, res) => {
    if (!KEY || !SECRET) {
      return res.status(500).send("Schoology API keys not configured");
    }

    const client = new (SchoologyAPI as any)(KEY, SECRET, "https://schoology.com");
    (client as any).requestAuthorization(async (err: any, url: string) => {
      if (err) return res.status(500).send("Authorization failed: " + err.message);
      
      await storage.updateSchoologyAuth({
        requestToken: client.oauth_token,
        requestTokenSecret: client.oauth_token_secret,
      });
      
      res.json({ url });
    });
  });

  app.get("/api/schoology/callback", async (req, res) => {
    if (!KEY || !SECRET) return res.status(500).send("Schoology API keys not configured");

    const auth = await storage.getSchoologyAuth();
    if (!auth?.requestToken) return res.status(400).send("No request token found");

    const client = new (SchoologyAPI as any)(KEY, SECRET);
    (client as any).oauth_token = auth.requestToken;
    (client as any).oauth_token_secret = auth.requestTokenSecret || "";

    (client as any).authorize(async (err: any) => {
      if (err) return res.status(500).send("Authorization failed: " + err.message);
      
      await storage.updateSchoologyAuth({
        accessToken: client.oauth_token,
        accessTokenSecret: client.oauth_token_secret,
      });
      
      res.redirect("/schoology?connected=true");
    });
  });

  app.get("/api/schoology/me", async (req, res) => {
    const auth = await storage.getSchoologyAuth();
    if (!auth?.accessToken) return res.status(401).json({ connected: false });

    const client = new (SchoologyAPI as any)(KEY!, SECRET!);
    (client as any).oauth_token = auth.accessToken;
    (client as any).oauth_token_secret = auth.accessTokenSecret || "";

    (client as any).get("/users/me", (err: any, data: any) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ ...data, connected: true });
    });
  });

  app.get("/api/schoology/sections", async (req, res) => {
    const auth = await storage.getSchoologyAuth();
    if (!auth?.accessToken) return res.status(401).json({ connected: false });

    const client = new (SchoologyAPI as any)(KEY!, SECRET!);
    (client as any).oauth_token = auth.accessToken;
    (client as any).oauth_token_secret = auth.accessTokenSecret || "";

    (client as any).get("/users/me/sections", (err: any, data: any) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(data?.section || []);
    });
  });

  app.get("/api/schoology/sections/:id/assignments", async (req, res) => {
    const auth = await storage.getSchoologyAuth();
    if (!auth?.accessToken) return res.status(401).json({ connected: false });

    const client = new (SchoologyAPI as any)(KEY!, SECRET!);
    (client as any).oauth_token = auth.accessToken;
    (client as any).oauth_token_secret = auth.accessTokenSecret || "";

    (client as any).get(`/sections/${req.params.id}/assignments`, (err: any, data: any) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(data?.assignment || []);
    });
  });

  app.get("/api/schoology/assignments/:id", async (req, res) => {
    const auth = await storage.getSchoologyAuth();
    if (!auth?.accessToken) return res.status(401).json({ connected: false });

    const client = new (SchoologyAPI as any)(KEY!, SECRET!);
    (client as any).oauth_token = auth.accessToken;
    (client as any).oauth_token_secret = auth.accessTokenSecret || "";

    (client as any).get(`/assignments/${req.params.id}`, (err: any, data: any) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(data);
    });
  });
}
