import { db } from "./db";
import { files, visitors, schoologyAuth, users, type InsertFile, type File, type InsertSchoologyAuth, type SchoologyAuth, type User, type InsertUser } from "@shared/schema";
import { eq, desc, sql } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // Files
  getFiles(): Promise<File[]>;
  createFile(file: InsertFile): Promise<File>;
  deleteFile(id: number): Promise<void>;
  // Visitors
  getUniqueVisitorCount(): Promise<number>;
  recordVisitor(ip: string): Promise<void>;
  // Schoology
  getSchoologyAuth(): Promise<SchoologyAuth | undefined>;
  updateSchoologyAuth(auth: Partial<InsertSchoologyAuth>): Promise<void>;
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser & { isDev?: number }): Promise<User>;
  updateUser(id: number, data: Partial<User>): Promise<void>;
  getAllUsers(): Promise<User[]>;
  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      conObject: {
        connectionString: process.env.DATABASE_URL,
      },
      createTableIfMissing: true,
    });
  }

  // Files
  async getFiles(): Promise<File[]> {
    return db.select().from(files).orderBy(desc(files.createdAt));
  }

  async createFile(file: InsertFile): Promise<File> {
    const [newFile] = await db.insert(files).values(file).returning();
    return newFile;
  }

  async deleteFile(id: number): Promise<void> {
    await db.delete(files).where(eq(files.id, id));
  }

  // Visitors
  async getUniqueVisitorCount(): Promise<number> {
    const result = await db.select({ count: sql<number>`count(*)` }).from(visitors);
    return Number(result[0]?.count || 0);
  }

  async recordVisitor(ip: string): Promise<void> {
    try {
      await db.insert(visitors).values({ ip }).onConflictDoNothing();
    } catch (e) {
      // Ignore duplicate IP errors or other db issues
    }
  }

  // Schoology
  async getSchoologyAuth(): Promise<SchoologyAuth | undefined> {
    const [auth] = await db.select().from(schoologyAuth).limit(1);
    return auth;
  }

  async updateSchoologyAuth(auth: Partial<InsertSchoologyAuth>): Promise<void> {
    const [existing] = await db.select().from(schoologyAuth).limit(1);
    if (existing) {
      await db.update(schoologyAuth).set({ ...auth, updatedAt: new Date() }).where(eq(schoologyAuth.id, existing.id));
    } else {
      await db.insert(schoologyAuth).values(auth as InsertSchoologyAuth);
    }
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(user: InsertUser & { isDev?: number }): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  async updateUser(id: number, data: Partial<User>): Promise<void> {
    await db.update(users).set(data).where(eq(users.id, id));
  }

  async getAllUsers(): Promise<User[]> {
    return db.select().from(users);
  }
}

export const storage = new DatabaseStorage();
