import type { Express } from "express";
import type { Server } from "http";
import { registerChatRoutes } from "./replit_integrations/chat/routes";
import { registerImageRoutes } from "./replit_integrations/image/routes";
import { registerSchoologyRoutes } from "./schoology";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup authentication
  setupAuth(app);

  // Middleware to track unique visitors by IP
  app.use(async (req, _res, next) => {
    const ip = req.ip || req.headers['x-forwarded-for']?.toString() || 'unknown';
    try {
      await storage.recordVisitor(ip);
    } catch (e) {
      console.error('Failed to record visitor:', e);
    }
    next();
  });

  // Visitor count endpoint
  app.get('/api/visitors/count', async (_req, res) => {
    const count = await storage.getUniqueVisitorCount();
    res.json({ count });
  });

  // Register AI integration routes
  registerChatRoutes(app);
  registerImageRoutes(app);
  registerSchoologyRoutes(app);

  // File routes for "trained data"
  app.get(api.files.list.path, async (req, res) => {
    const files = await storage.getFiles();
    res.json(files);
  });

  app.post(api.files.upload.path, async (req, res) => {
    try {
      const input = api.files.upload.input.parse(req.body);
      const file = await storage.createFile(input);
      res.status(201).json(file);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.delete(api.files.delete.path, async (req, res) => {
    await storage.deleteFile(Number(req.params.id));
    res.sendStatus(204);
  });

  return httpServer;
}
